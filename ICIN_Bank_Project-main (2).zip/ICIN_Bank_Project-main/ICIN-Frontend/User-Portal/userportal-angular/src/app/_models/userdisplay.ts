export class UserDisplay{

    primaryAccno:number;
    savingsAccno:number;
    primaryBalance:number;
    savingsBalance:number;

}